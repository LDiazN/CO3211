%{Ejercicio1: Las funciones pedidas están en los siguientes archivos:
 
  gaussNoPiv.m: Gauss sin pivoteo.
  gaussPiv.m: Gauss con pivoteo.
  LUfact.m: Factorización LU, devuelve dos matrices, L y U.
  sustback.m: Sustitución hacia atrás.
  sustfor.m: Sustitución hacia adelante.

%}