%Fx.m; recibe un número real x y devuelve el valor de 

function y = Fx (x)
  y = x*sin(x)/((x^2) + 1);
endfunction
