%test.m

[paraguana_1x,paraguana_1y] = captura_puntos('paraguana1.bmp');
save data.mat paraguana_1x paraguana_1y
[paraguana_2x,paraguana_2y] = captura_puntos('paraguana2.bmp');
save data.mat paraguana_2x paraguana_2y
[paraguana_3x,paraguana_3y] = captura_puntos('paraguana3.bmp');
save data.mat paraguana_3x paraguana_3y
[paraguana_4x,paraguana_4y] = captura_puntos('paraguana4.bmp');
save data.mat paraguana_4x paraguana_4y
[paraguana_5x,paraguana_5y] = captura_puntos('paraguana5.bmp');
save data.mat paraguana_5x paraguana_5y
[paraguana_6x,paraguana_6y] = captura_puntos('paraguana6.bmp');
save data.mat paraguana_6x paraguana_6y
[paraguana_7x,paraguana_7y] = captura_puntos('paraguana7.bmp');
save data.mat paraguana_7x paraguana_7y
[paraguana_8x,paraguana_8y] = captura_puntos('paraguana8.bmp');
save data.mat paraguana_8x paraguana_8y
[paraguana_9x,paraguana_9y] = captura_puntos('paraguana9.bmp');
save data.mat paraguana_9x paraguana_9y
[paraguana_10x,paraguana_10y] = captura_puntos('paraguana10.bmp');
save data.mat paraguana_10x paraguana_10y
[paraguana_11x,paraguana_11y] = captura_puntos('paraguana11.bmp');
save data.mat paraguana_11x paraguana_11y
[paraguana_12x,paraguana_12y] = captura_puntos('paraguana12.bmp');
save data.mat paraguana_12x paraguana_12y
[paraguana_13x,paraguana_13y] = captura_puntos('paraguana13.bmp');
save data.mat paraguana_13x paraguana_13y
[paraguana_14x,paraguana_14y] = captura_puntos('paraguana14.bmp');
save data.mat paraguana_1x paraguana_1y paraguana_2x paraguana_2y paraguana_3x paraguana_3y paraguana_4x paraguana_4y paraguana_5x paraguana_5y paraguana_6x paraguana_6y  paraguana_7x paraguana_7y paraguana_8x paraguana_8y paraguana_9x paraguana_9y paraguana_10x paraguana_10y paraguana_11x paraguana_11y paraguana_12x paraguana_12y paraguana_13x paraguana_13y paraguana_14x paraguana_14y
